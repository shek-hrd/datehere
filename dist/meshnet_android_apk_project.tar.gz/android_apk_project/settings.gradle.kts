rootProject.name = "MeshNet"
include(":app")
